export class GetUserCartDto {
    readonly req: any;

    constructor(req: any) {
        this.req = req;
    }
}
